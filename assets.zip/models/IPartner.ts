export interface IPartner {
  id: number
  logo: string
  name: string
}