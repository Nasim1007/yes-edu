export interface ICourse {
  id: number
  name: string
  icon: string
  type: string
}