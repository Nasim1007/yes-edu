export interface ILead {
  firstName: string
  phone: string
  course: string
}