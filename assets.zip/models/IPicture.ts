export interface IPicture {
  jpg: string
  webp?: string
  title?: string
}