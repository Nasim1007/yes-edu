export interface IVacancy {
  id: number
  name: string
  experience: string
  schedule: string
  salary: string
}