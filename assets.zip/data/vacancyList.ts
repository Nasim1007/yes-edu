import { IVacancy } from '../models/IVacancy'

export const vacancyList: IVacancy[] = [
  {
    id: 1,
    name: 'Преподаватель по русскому языку',
    experience: 'от 2 лет',
    schedule: 'Свободный',
    salary: 'Договорная'
  },
  {
    id: 2,
    name: 'Преподаватель по русскому языку',
    experience: 'от 2 лет',
    schedule: 'Свободный',
    salary: 'Договорная'
  },
  {
    id: 3,
    name: 'Преподаватель по русскому языку',
    experience: 'от 2 лет',
    schedule: 'Свободный',
    salary: 'Договорная'
  },
  {
    id: 4,
    name: 'Преподаватель по немецкому языку',
    experience: 'от 2 лет',
    schedule: 'Свободный',
    salary: 'Договорная'
  },
  {
    id: 5,
    name: 'Преподаватель по математике',
    experience: 'от 2 лет',
    schedule: 'Свободный',
    salary: 'Договорная'
  },
  {
    id: 6,
    name: 'Преподаватель по химии',
    experience: 'от 2 лет',
    schedule: 'Свободный',
    salary: 'Договорная'
  },
]